import textrazor
from textblob import TextBlob
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException
from starlette.responses import HTMLResponse

#Key and url of newsapi
API_KEY = "994575a525dc47c69c4098686186aff0"
BASE_URL = "https://newsapi.org/v2/everything"

#We use the website technologyreview and we filter the AI related articles
params = {
    "domains": "technologyreview.com",
    "q": "AI",
    "apiKey": API_KEY
}

app=FastAPI()
#Request to get the AI articles
response = requests.get(BASE_URL, params=params)

#Function that return a list of dictionnary containing information about the article
def data():
    #
    articles = response.json().get('articles', [])
    #Check that the request worked
    if response.status_code == 200:
        return articles
    else: return {"Error the articles can't be loaded"}

#First page containing a few informations about our API
@app.get("/", response_class=HTMLResponse)
async def root():
    html_content = """
    <html>
        <head>
            <title>Home</title>
        </head>
        <body>
            <h1>Project Python git linux</h1>
            <p>Geoffroy Lainé, Erwann Kerlaouezo et Tom Grangier</p>
            <p>Endpoints of the API:</p>
            <ul>
                <li>/get_data : get the list of articles</li>
                <li>/articles : infomations about the articles</li>
                <li>/article/nbr : content of the specified article</li>
                <li>/ml/nbr: Sentiment analysis of the specified article</li>
            </ul>
        </body>
    </html>
    """
    return HTMLResponse(content=html_content)

#Function that return a list of articles withe the title and url
@app.get('/get_data')
async def get_data():
    articles=data()
    #informations we want to keep
    keys=["title","url"]
    #new dictionnary containing only title and url
    dict = [{k: article[k] for k in keys if k in article} for article in articles]
    return dict

#Function that returns the article number,title,author,publishing date and a short description
@app.get('/articles')
async def articles():
  articles=data()
  for article in articles:
    #get the article number located in the url
    nbr=article['url'].split("/")[-3]
    #add it to the dictionnary
    article["number"]=nbr
    #convert the date to a more readable format
    date_iso = datetime.strptime(article['publishedAt'],"%Y-%m-%dT%H:%M:%SZ")
    date = date_iso.strftime("%d %B %Y")
    #add the date to the dictionnary
    article["date"]=date
    #select the categories we want to keep in dict
    keys = ["title","number","author","date","description"]
    dict = [{k: article[k] for k in keys if k in article} for article in articles]
  return dict

#Function that return the content of a specified article number
@app.get('/article/{nbr}')
async def article_content(nbr: str):
    articles = data()
    #we check the article number of every article until we found the right one
    for article in articles:
        if article['url'].split("/")[-3] == nbr:
            url = article['url']
            #request the article using it's url
            response = requests.get(url)
            html_content = response.text
            #parse the page using beautifulSoup to get only the content of the article
            soup = BeautifulSoup(html_content, 'html.parser')
            #select the class where the content of the artcle is located
            content_div = soup.find("div", class_="contentBody__wrapper--d9d8f9bb44c188246f70afcdc827cc4f")
            #if the text as been found return it
            if content_div:
                content_text = content_div.get_text(strip=True)
                return {"Article number": nbr, "content": content_text}
            else:
                return {"Article number": nbr, "content": "Content not found"}

    return {"Article number": nbr, "content": "Article not found"}


# Endpoint to perform sentiment analysis and to find the main topics on an article
@app.get("/ml/{nbr}")
async def sentiment_analysis(nbr: str):
    # Retrieve the content and the number of the article
    article_info = await article_content(nbr)
    if not article_info:
        # If the article is not found, raise a 404 HTTP exception
        raise HTTPException(status_code=404, detail="Article not found")

    # Extract just the content of the article
    article_c = article_info["content"]

    # Create a TextBlob object with the content of the article
    blob = TextBlob(article_c)

    # Retrieve the polarity and subjectivity scores of the article's sentiment
    polarity = blob.sentiment.polarity
    subjectivity = blob.sentiment.subjectivity

    # Analyzing and interpreting the polarity
    if polarity < -0.5:
        polarity_desc = "The article expresses a very negative sentiment, indicating strong criticism or unfavorable opinions."
    elif polarity < 0:
        polarity_desc = "The article presents slightly negative opinions or critical aspects."
    elif polarity < 0.5:
        polarity_desc = "The article expresses positive sentiments, although they may be moderate or nuanced."
    else:
        polarity_desc = "The article conveys a very positive sentiment, reflecting marked appreciation or enthusiasm."

    # Analyzing and interpreting the subjectivity
    if subjectivity < 0.25:
        subjectivity_desc = "The article is very objective, providing facts and information without perceptible bias or personal opinions."
    elif subjectivity < 0.5:
        subjectivity_desc = "Although containing factual information, the article presents some subjectivity or personal perspectives."
    elif subjectivity < 0.75:
        subjectivity_desc = "The article shows notable subjectivity, with opinions and personal interpretations having a significant impact on the content."
    else:
        subjectivity_desc = "The article is highly subjective, dominated by personal opinions, assessments, and interpretations."

    textrazor.api_key = "85cce81f3460666c9895fc2362000bc703a318bda62760aa7587d566"

    # Initialize the TextRazor client
    content_text = str(article_c)
    client = textrazor.TextRazor(extractors=["topics"])
    client.set_language_override('eng')

    # Analyze the content of the article
    resp = client.analyze(content_text)

    topics = set()
    # Extract topics from the article
    for topic in resp.topics():
        if topic.score > 0.9:  # we filter the topics to keep the most relevant
            topics.add(topic.label)

    # Returning results with detailed descriptions
    return {
        "article_number": nbr,
        "polarity_description": polarity_desc,
        "subjectivity_description": subjectivity_desc,
        "topics":topics,
    }



if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)